<?php 

require_once "../../php/Header.php";

?>
<form> 
	<label for = "ProfileNewPicture"> Profile Picture </label>
	<input id = "ProfileNewPicture" type = "file">
	<input id = "ProfileNewPicture" type = "submit">
</form>

<form> 
	<label for = "ProfileNewEmail"> New Email </label>
	<input id = "ProfileNewEmail" type = "email">
	<input id = "ProfileNewEmailSubmit" type = "submit">
</form>

<form>
	<label for = "ProfileOldPassword"> Current Password </label>
	<input id = "ProfileOldPassword" type = "Password">
	<label for = "ProfileNewPassword"> New Password </label>
	<input id = "ProfileNewPassword" type = "Password">
	<label for = "ProfileNewPasswordConfirm"> Confirm New Password </label>
	<input id = "ProfileNewPasswordConfirm" type = "Password">
	<input id ="ProfileNewPasswordSubmit" type = "submit">
</form>

