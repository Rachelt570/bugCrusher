<!DOCTYPE html>

	
<html>
<head>
	<title>Bug crusher</title>
</head>
<body>
	<?php
		include_once 'php/Header.php';
		include_once 'php/Main.php';
		include_once 'php/Messages.php';
	?>
</body>
</html>