


// To do: 


// I. "Create Messagebox class"
// II. Rewrite code to accomidate many message boxes
// III. Upload profile picture
// IV. Rewrite code to fetch correct profile picture
// V. Rewrite PHP message method to grab correct messages
// VI. Encrypt messages PGP



$(document).ready(function()
{
	var targetName = "";
	$("#UserNameID").keyup(function() {
		targetName =  ($(this).val());
	});
	var MessageHandler = new Messager(1);
    function GetMessages()
    {

    	let fData = {targetName: targetName};
   		$.ajax({
   			type: "POST",
   			data: fData,
   			url: "http://localhost/Bug-tracker/Scripts/php/GetMessages.inc.php",
  			success: function(data)
   			{
   				console.log(data);

   				var JsonData = JSON.parse(data);
   				var data = [];
   				for(let i in JsonData)
   				{
   					data.push(Object.values(JsonData[i]));
   					m = new Message(data[i][0], data[i][1], data[i][2], data[i][3]);
 					if(!MessageHandler.isDispayed(m))
   					{
   						MessageHandler.display(m);
   					}
   				}
   			}
   		});
   	};
   	var getMessagesInterval = setInterval(GetMessages, 1000)
    });
class Messager
{
	constructor(UID)
	{
		this._UID = UID;
		this._messageList = [];
	}
	isDispayed(m)
	{
		return this._messageList.includes(m.MID);
	}
	display(m)
	{
		this._messageList.push(m.MID);
		var content = "";
		if(this.isIncoming(m))
		{
			content += "<li class = 'IncomingMessage Message'>";
		}
		else
		{
			content += "<li class = 'OutgoingMessage Message'>";  
		}
		content += "<img class = 'MessageProfilePicture' src = '#'>";
		content += "<p class = 'MessageContent'>";
		content += m.Content + "</p> </li>";
		$(".MessageList").append(content);
	}
	isOutgoing(m)
	{
		return this.UID === m.SID;
		return this.UID ===  SID;
	}
	isIncoming(m)
	{
		return this.UID === m.RID;
	}
	get UID()
	{
		return this._UID;
	}
	set UID(UID)
	{
		this._UID = UID;
		return;
	}
	get SID() 
	{
		return this._SID;
	}
	set SID(SID)
	{
		this._SID = _SID;
	}
} 

class Message 
{
	constructor(MID, SID, RID, Content)
	{
		this._MID = MID;
		this._SID = MID;
		this._RID = RID;
		this._Content = Content;
	}
	get MID() 
	{
		return this._MID;
	}
	get RID()
	{
		return this._RID;
	}
	get SID()
	{
		return this.SID;
	}
	get Content()
	{
		return this._Content;
	}
}
function handleForm(e) { event.preventDefault(); } 
$("#MessageBoxOne").submit(function(e) {
	e.preventDefault();
})

var MessageHandler = new Messager(1);
function displayMessages(messages) 
{
	
	

}
function sendMessage() {
	var targetName = $("#UserNameID").val();
	var messageContent = $("#MessageInputID").val();
	var fData = new FormData();
	fData.append("MessageInput", messageContent);
	fData.append("MessageTargetName", targetName);
	fetch("http://localhost/Bug-tracker/Scripts/php/Messages.inc.php", {method: "POST", body: fData}).then(response => {
		if (!response.ok) {
			throw new Error("Network response not okay");
		}
	}).catch(err => console.log(err));
	}
