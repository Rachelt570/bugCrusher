

class MessageBox
{

	var messageBoxID;
	var targetName;
	var messageList = [];


}