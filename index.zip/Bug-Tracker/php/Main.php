<?php 


echo '

<h2> My Teams: </h2>
<form id = "createTeam"> 
	<label for = "newTeamName"> Name </label> 
	<input type = "text" name = "newTeamName">
	<input type = "submit" name = "createTeamSubmit" value = "Create New Team" action = "scripts/php/createNewTeam.inc.php">
</form>

<ul>
	<li> 
		<h3> Example Team Name
			<h4> Admin List </h4>
			<ul>
				<li> <img src = "#"> <a href = "#"> Example Admin </a> </li>
			</ul>
			<h4> Developer List </h4>
			<ul>
				<li> <img src = "#"> <a href = "#"> Example Developer </a> </li>
			</ul>
			<h4> Project List </h4>
			<ul>  
				<li> 
					<img src = "#"> <a href = "#"> Example Project </a> 
					<ul> </ul>

				</li>
			</ul>
		</h3>
		<h3> Example Team two </h3>

	</li>

 </ul>


';
?>