<?php 
	$WebsiteHost = "http://localhost/Bug-Tracker";
echo
'<header>  
	<a href = ' . $WebsiteHost .'/Index.php> <h1>  Bug Crusher </h1> </a>
</header>

<script type="text/javascript" src = "' . $WebsiteHost . '/Scripts/js/jquery.js"></script>
<link rel="stylesheet" type="text/css" href=" ' . $WebsiteHost . '/Styles/main.css">
<script type="text/javascript" src = " ' . $WebsiteHost . '/Scripts/js/messaging.js"></script>
';
?>
<?php 


	session_start();
	if(isset($_SESSION["UID"]))
	{
		echo
		'
			<form id = "LogoutForm" action = " '. $WebsiteHost . '/Scripts/php/signout.inc.php" method = "post" >
			<input type = "Submit" value = "Logout">
		';
		$profileLink = $WebsiteHost . "/Profiles/" . $_SESSION["Username"] . "/";
		$pictureLink = $profileLink . "/Picture.png";

		echo ' <a href = ' . $profileLink . 'Settings.php> <img class = "ProfilePicture" src = ' . $pictureLink . '> </a> ';
		echo $_SESSION["Username"];
	}
	else
	{
		echo 
			'

				<form id = "Login-Form" action = " ' . $WebsiteHost . '/Scripts/php/signin.inc.php" method = "post" >
				<label for = "Username"> Username </label>
				<input type="text" name="LoginUsername"> 
				<label for = "Password"> Password </label>
				<input type="Password" name = "LoginPassword"> 
				<input type = "Submit" name = "LoginSubmit" value = "Sign-In"> 
				</form>

				<p> Do not have any account? </p>
				<a href = "'. $WebsiteHost . '/signup.php"> Sign up </a> <br>
				<a href = "'. $WebsiteHost . '/testMode.php"> Test Mode </a>
			';

	}

