

<?php 

echo ' 
<form class = "MessageBox" enctype="multipart/form-data"  id = "MessageBoxOne" onsubmit = "return false"> 		

<img src = "Assets/Joker.png" class = "ProfilePicture MessageBoxProfilePicture"> <span class = "UsersNameContainer"> <input type = "Text"  id = "UserNameID" name = "MessageTargetName" class = "UsersName"> </span>
<button class = "MinimizeMessage"> <img class = "MinimizeImage" src = "Assets/Minimize.png"> </button>
<button class = "CloseMessage"> <img class = "CloseImage" src = "Assets/Close.png"> </button>
<ul class = "MessageList"> 


</ul>
<input type = "text" class = "MessageInput" id = "MessageInputID" name = "MessageInput"> <button type = "submit" onclick = "	javascript:sendMessage()" name = "MessageSubmit" class = "SendMessage"> <img class  = "SendMessageImage" src = "Assets/Send.png"> </button>
</form>

';

	