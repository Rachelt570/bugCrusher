<!DOCTYPE html>
<html>
<head>
	<title>
	Rachel Casey	
	</title>
</head>
<body>
	<header>
		<img src="#">
		<h1> Rachel Casey </h1>
	</header>
	<main>
		<h2> Projects </h2>
		<article>
			<h3> Visualizing Sorting Algorithms </h3>
			<a href = "Projects/Visualizing-Sorting-Algorithms.php"> Live Source </a>
			<a href = "https://github.com/Rachelt570/Sorting-Algorithm-Visualizer"> Source Code </a>
		</article>
		<article> 
			<h3> Bug Tracker </h3>
			<a href = "Projects/BugTracker"> Live Source </a>
			<a href = "https://github.com/Rachelt570/Bugtracker"> Source Code </a>
		</article>
		<article>
			<h3> Web Crawler </h3>
			<a href = "Projects/WebCrawler"> Web Crawler </a>
			<a href = "https://github.com/Rachelt570/WebCrawler"> Source Code </a>
		</article>
	</main>
	<footer>
		<h2> Contact </h2>
		<a href = "tel:587-917-9347"> (587) 917-9347 </a>
		<a href = "Mailto: Contact@Rachel-Casey.com"> Contact@Rachel-Casey.com </a>
	</footer>
</body>
</html>